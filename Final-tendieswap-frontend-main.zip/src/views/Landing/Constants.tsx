export default {
  facebookURL: "https://www.facebook.com/TendieSwap-100390755631326",
  twitterURL: "https://www.twitter.com/tendie_swap",
  instagramURL: "https://z-p42.www.instagram.com/tendie.swap",
  pancakeURL: "https://pancakeswap.info/token/0x9853A30C69474BeD37595F9B149ad634b5c323d9",
}