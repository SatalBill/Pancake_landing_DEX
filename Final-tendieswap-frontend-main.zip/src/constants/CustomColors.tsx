export default {
  Grad1: "#ea852d",
  Grad2: "#e4442e",
  FightbgColor: "#1c1c1e",
  CardbgColor: "#27262c",
  CardTitle: "#dc3c3c",
  Price: "#68251c",
  Submit: "#eb8930",
  SubmitHover: "#eaa86b",
  SubmitActive: "#e47007",
}